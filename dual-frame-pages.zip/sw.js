// offline cache: the game works without a connection once it has been opened
const C = 'dual-frame-98bc3a71d9';
const FILES = ['./', 'index.html', 'three.min.js', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png', 'apple-touch-icon.png'];
self.addEventListener('install', (e) => { self.skipWaiting(); e.waitUntil(caches.open(C).then((c) => c.addAll(FILES))); });
self.addEventListener('activate', (e) => e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== C).map((k) => caches.delete(k)))).then(() => self.clients.claim())));
self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  // page itself: network first so updates show up; everything else: cache first
  const page = e.request.mode === 'navigate';
  e.respondWith(page
    ? fetch(e.request).then((r) => { const cp = r.clone(); caches.open(C).then((c) => c.put('./', cp)); return r; }).catch(() => caches.match('./'))
    : caches.match(e.request).then((hit) => hit || fetch(e.request).then((r) => { if (r.ok || r.type === 'opaque') { const cp = r.clone(); caches.open(C).then((c) => c.put(e.request, cp)); } return r; })));
});
